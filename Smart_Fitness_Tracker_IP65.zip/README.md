# Smart Fitness Tracker (IP65) — Accuracy Enhanced
**Author:** Md Rehan Raza

## Project Overview
Smart wearable fitness tracker prototype (IP65-rated enclosure) that measures steps and heart rate. Initial algorithm accuracy ~70%; improved to **~80%** using sensor fusion, calibration, and filtering. Implemented with C/C++ (firmware), Python (data processing & ML calibration), and JavaScript (dashboard).

## Key Features
- Step counting and heart-rate monitoring
- IP65 enclosure (dust-tight, water-spray resistant)
- Accuracy improvement from ~70% → ~80% via sensor fusion (MPU6050 + algorithm tuning)
- Local data logging and optional web dashboard
- Complete repo with firmware, processing scripts, docs, and deployment instructions

## Tech Stack
- Hardware: ESP32/Arduino, MPU6050 (accelerometer+gyro), MAX30102 (heart-rate), LiPo battery, IP65 enclosure
- Firmware: C/C++ (Arduino IDE / PlatformIO)
- Processing: Python (NumPy, Pandas, SciPy), optional ML model for activity classification
- Dashboard: JavaScript (Chart.js) + HTML/CSS or Streamlit for quick demos
- Deployment: GitHub repo, Streamlit Cloud or GitHub Pages for dashboard

## Repo Structure
```
Smart_Fitness_Tracker_IP65/
├── hardware/
│   ├── schematic.png
│   └── BOM.csv
├── firmware/
│   └── tracker.ino
├── python/
│   ├── process_data.py
│   └── calibrate.py
├── web_dashboard/
│   └── index.html
├── docs/
│   └── Smart_Fitness_Tracker_Documentary.pdf
├── README.md
└── LICENSE
```

## How Accuracy Was Improved (70% → 80%)
1. **Sensor Fusion:** Combined accelerometer and gyroscope data (MPU6050) to reduce false step detections.  
2. **Filtering:** Applied moving average and a lightweight Kalman filter to smooth noisy signals.  
3. **Adaptive Thresholding:** Dynamically adjusted step-detection threshold based on user stride calibration and activity level.  
4. **Post-processing:** Used Python to analyze logged data and apply corrections (debounce logic, peak detection tuning).

## Validation Methodology
- Collected labeled ground-truth data (walking trials) across multiple users and surfaces.  
- Measured steps counted vs ground truth and heart-rate vs reference device.  
- Computed accuracy = (correct detections / total events) × 100% before and after improvements.

## Deployment & Publication
- Publish full repo on GitHub under `MdRehanRaza/Smart-Fitness-Tracker-IP65`.  
- Include `docs/Smart_Fitness_Tracker_Documentary.pdf` with details, and a short demo video link.  
- Author and copyright: **Md Rehan Raza**

---
