# calibrate.py - simple calibration routine to tune threshold based on ground truth
import pandas as pd, numpy as np
def calibrate(df, true_steps):
    # brute-force find threshold that best matches true_steps
    mags = (df['ax']**2 + df['ay']**2 + df['az']**2)**0.5
    best = None
    for k in np.linspace(mags.mean(), mags.max(), 50):
        est = (mags > k).sum()
        err = abs(est - true_steps)
        if best is None or err < best[0]:
            best = (err, k, est)
    return {'best_threshold': best[1], 'estimated': best[2], 'error': best[0]}