# process_data.py - read JSON lines from serial or file, apply smoothing and step detection
import json, math, argparse
import numpy as np, pandas as pd
from scipy.signal import medfilt

def read_file(path):
    rows = []
    with open(path, 'r') as f:
        for line in f:
            try:
                obj = json.loads(line.strip())
                rows.append(obj)
            except:
                continue
    return pd.DataFrame(rows)

def magnitude(df):
    return np.sqrt(df['ax']**2 + df['ay']**2 + df['az']**2)

def moving_avg(x, window=5):
    return x.rolling(window, center=True).mean().fillna(method='bfill').fillna(method='ffill')

def detect_steps(df, thresh=10000):
    mag = magnitude(df)
    s = moving_avg(mag, window=3)
    peaks = (s > thresh)
    # simple count (improve with peak detection)
    return peaks.sum()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data.jsonl", help="input JSONL file")
    args = parser.parse_args()
    df = read_file(args.input)
    df['mag'] = magnitude(df)
    df['mag_smooth'] = moving_avg(df['mag'], window=5)
    steps = detect_steps(df, thresh=df['mag_smooth'].mean() + df['mag_smooth'].std())
    print("Estimated steps:", steps)